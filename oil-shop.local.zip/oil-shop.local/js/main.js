
async function loadPartials() {
  // header
  const h = await fetch('/header.html').then(r => r.text());
  const hEl = document.getElementById('_header');
  if (hEl) {
    hEl.innerHTML = h;
    // инициализируем шапку и бейдж после вставки
    await initAuthUI();
    await updateCartBadge();
  }
  // footer
  const f = await fetch('/footer.html').then(r => r.text());
  const fEl = document.getElementById('_footer');
  if (fEl) fEl.innerHTML = f;
}

function escapeHtml(s){
  return (s||'').toString().replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[c]));
}
function money(n){
  return Number(n||0).toFixed(2).replace('.',',')+' ₽';
}
function showError(err){
  const el=document.getElementById('flash');
  if(!el) return;
  el.textContent = 'Ошибка: '+(err?.message||err);
  el.classList.remove('d-none');
}

/* ------------------------ API (с куками) ------------------------ */
async function apiGet(url){
  const r = await fetch(url, { credentials:'include' });
  return r.json();
}
async function apiPost(url, body){
  const r = await fetch(url, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(body || {}),
    credentials:'include'
  });
  let data; try{ data = await r.json(); } catch { data = {}; }
  return { ok: r.ok, data, status: r.status };
}

/* ------------------------ AUTH UI (шапка) ------------------------ */
async function initAuthUI(){
  const guest = document.querySelector('.auth-guest');
  const user  = document.querySelector('.auth-user');

  try{
    const me = await apiGet('/php/auth_me.php'); // {ok:true,user:{...}} или {ok:false}
    if(me && me.ok){
      if(guest) guest.classList.add('d-none');
      if(user)  user.classList.remove('d-none');
      const span = document.getElementById('meEmail'); if(span) span.textContent = me.user.email;
      // logout
      const btn = document.getElementById('logoutBtn');
      if(btn) btn.onclick = async ()=>{
        await apiPost('/php/auth_logout.php',{});
        location.href='index.html';
      };
      // продублируем переключатель темы
      const t1 = document.getElementById('themeToggle');
      const t2 = document.getElementById('themeToggle2');
      if(t1 && t2){ t2.onclick = t1.onclick || null; }
    }else{
      if(user)  user.classList.add('d-none');
      if(guest) guest.classList.remove('d-none');
    }
  }catch(e){
    // шапку оставим
  }
}

function setupPasswordHints(inputId, helpId){
  const el=document.getElementById(inputId), help=document.getElementById(helpId);
  if(!el || !help) return;
  const tests=[
    {re:/.{7,}/, text:'≥ 7 символов'},
    {re:/[A-Z]/, text:'Заглавная A–Z'},
    {re:/[a-z]/, text:'Строчная a–z'},
    {re:/\d/,    text:'Цифра'},
    {re:/[^A-Za-z0-9_ ]/, text:'Спецсимвол'},
    {re:/\s/, text:'Пробел'},
    {re:/-/, text:'Дефис -'},
    {re:/_/, text:'Подчёркивание _'},
    {re:/[А-Яа-яЁё]/u, not:true, text:'Нет русских букв'}
  ];
  function render(){
    const v=el.value; help.innerHTML=tests.map(t=>{
      const ok=t.not?!t.re.test(v):t.re.test(v);
      return `<span class="badge ${ok?'bg-success':'bg-secondary'} me-1 mb-1">${t.text}</span>`;
    }).join('');
  }
  ['input','focus'].forEach(ev=>el.addEventListener(ev,render));
  render();
}

/* ------------------------ КАРТОЧКИ ТОВАРОВ ------------------------ */
function renderCards(containerId, items){
  const box = document.getElementById(containerId);
  if(!box) return;
  if(!items || !items.length){ box.innerHTML='<div class="text-muted">Нет товаров</div>'; return; }

  box.innerHTML = '';
  items.forEach(p=>{
    const col = document.createElement('div');
    col.className = 'col-12 col-sm-6 col-md-4 col-lg-3';

    // безопасные значения
    const pid   = Number(p.id || 0);
    const name  = String(p.name || '');
    const vol   = Number(p.volume_liters ?? p.default_volume ?? 1); // если нет выбора литража, берём 1 л
    const ppl   = Number(p.price_per_liter ?? p.ppl ?? 0);

    col.innerHTML = `
      <div class="card h-100" data-product-id="${pid}">
        <div class="ratio ratio-4x3">
          <img src="${escapeHtml(p.image_url||'images/placeholder.png')}" class="card-img-top" alt="${escapeHtml(name)}">
        </div>
        <div class="card-body d-flex flex-column">
          <h3 class="card-title h6 mb-1">${escapeHtml(name)}</h3>
          <div class="text-muted small mb-2">${escapeHtml(p.brand)} • ${escapeHtml(p.viscosity||'')}</div>
          ${p.discount>0
            ? `<div class="price-line mb-0">${p.price_fmt}</div><div class="price-big mb-3">${p.final_fmt} / л</div>`
            : `<div class="price-big mb-3">${p.price_fmt || money(ppl)} / л</div>`}
          <a href="product.html?id=${pid}" class="stretched-link" aria-label="${escapeHtml(name)}"></a>
          <button class="btn btn-outline-primary"
                  data-add-to-cart
                  data-product-id="${pid}"
                  data-name="${escapeHtml(name)}"
                  data-volume-l="${vol}"
                  data-price-per-liter="${ppl}"
                  data-qty="1">Купить</button>
        </div>
      </div>`;
    box.appendChild(col);
  });
}

/* ------------------------ КОРЗИНА (SERVER-SIDE) ------------------------ */
// бейдж в шапке
async function updateCartBadge(){
  try{
    const c = await fetch('/php/cart_get.php', {credentials:'include'}).then(r=>r.json());
    const b1=document.getElementById('cart-badge'), b2=document.getElementById('cart-badge2');
    if(b1) b1.textContent=c.count||0; if(b2) b2.textContent=c.count||0;
  }catch{}
}

// добавление в корзину
document.addEventListener('click', async (e)=>{
  const btn=e.target.closest('[data-add-to-cart]'); if(!btn) return;
  e.preventDefault();

  const productId = Number(btn.dataset.productId || 0);
  const volume    = Number(btn.dataset.volumeL || 1);
  const qty       = Number(btn.dataset.qty || 1);

  if (!productId) { alert('Не удалось определить товар'); return; }

  btn.disabled=true;
  const res = await fetch('/php/cart_add.php', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    credentials:'include',
    body: JSON.stringify({product_id:productId, volume_l:volume, qty})
  });
  let data={}; try{ data=await res.json(); }catch{}
  btn.disabled=false;
  if(res.ok){
    updateCartBadge();
    btn.classList.replace('btn-outline-primary','btn-primary');
    setTimeout(()=>btn.classList.replace('btn-primary','btn-outline-primary'),700);
  } else {
    alert(data?.error || `Не удалось добавить (HTTP ${res.status})`);
  }
});

// отрисовка корзины на странице cart.html
async function renderCart(){
  const listEl = document.getElementById('cartTable');
  if(!listEl) return;
  try{
    const c = await apiGet('/php/cart_get.php');
    if(!c.items || !c.items.length){
      listEl.innerHTML = '<div class="text-muted">Корзина пуста</div>';
      return;
    }
    const rows = c.items.map(i=>`
      <tr>
        <td>${escapeHtml(i.name)}</td>
        <td>${i.volume_l} л</td>
        <td>${i.qty}</td>
        <td class="text-end">${i.unit_fmt}</td>
        <td class="text-end">${i.sum_fmt}</td>
        <td class="text-end">
          <button class="btn btn-sm btn-outline-danger" data-remove-key="${i.key}">×</button>
        </td>
      </tr>`).join('');

    listEl.innerHTML = `
      <div class="table-responsive">
        <table class="table align-middle">
          <thead><tr><th>Товар</th><th>Литры</th><th>Кол-во</th><th>Цена/ед.</th><th>Сумма</th><th></th></tr></thead>
          <tbody>${rows}</tbody>
          <tfoot><tr><th colspan="4" class="text-end">Итого:</th><th class="text-end">${c.total_fmt}</th><th></th></tr></tfoot>
        </table>
      </div>`;
  }catch(e){
    listEl.innerHTML = '<div class="alert alert-danger">Ошибка загрузки корзины</div>';
  }
}

// удаление позиции из корзины
document.addEventListener('click', async (e)=>{
  const rm = e.target.closest('[data-remove-key]');
  if(!rm) return;
  const key = rm.dataset.removeKey;
  const {ok} = await apiPost('/php/cart_remove.php',{key});
  if(ok){ await updateCartBadge(); renderCart(); }
});

/* ------------------------ АВТО-ИНИЦИАЛИЗАЦИЯ ------------------------ */
window.addEventListener('DOMContentLoaded', ()=>{
  if(document.getElementById('_header') && document.getElementById('_header').children.length){
    initAuthUI(); updateCartBadge();
  }
});
