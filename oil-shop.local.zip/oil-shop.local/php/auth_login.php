<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/session_boot.php';
require __DIR__ . '/db.php';

const DEBUG_LOGIN = true;

function inparam(string $key, $default = '')
{
    static $json = null;
    if ($json === null) {
        $raw = file_get_contents('php://input');
        $json = $raw ? json_decode($raw, true) : null;
    }
    if (is_array($json) && array_key_exists($key, $json))
        return $json[$key];
    return $_POST[$key] ?? $default;
}

function verify_pass(string $input, string $hash): bool
{
    if ($hash === '')
        return false;
    if (strpos($hash, '$2y$') === 0 || strpos($hash, '$argon2') === 0) {
        return password_verify($input, $hash);
    }
    return hash_equals($hash, $input);
}

function detect_user_columns(PDO $pdo): array
{
    $cols = [];
    foreach ($pdo->query("SHOW COLUMNS FROM users") as $r) {
        $name = $r['Field'] ?? $r[0];
        $cols[$name] = true;
    }
    // email/login
    $emailCol = 'email';
    foreach (['email', 'mail', 'login', 'username'] as $c) {
        if (isset($cols[$c])) {
            $emailCol = $c;
            break;
        }
    }
    // password hash
    $passCol = 'password';
    foreach (['password', 'pass_hash', 'pass'] as $c) {
        if (isset($cols[$c])) {
            $passCol = $c;
            break;
        }
    }
    // id
    $idCol = isset($cols['id']) ? 'id' : (isset($cols['user_id']) ? 'user_id' : 'id');
    return [$idCol, $emailCol, $passCol];
}

try {
    if (!empty($_SESSION['user_id'])) {
        echo json_encode([
            'ok' => true,
            'user' => [
                'id' => (int) $_SESSION['user_id'],
                'email' => (string) ($_SESSION['email'] ?? '')
            ]
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $email = trim((string) inparam('email', ''));
    $pass = (string) inparam('password', '');

    if ($email === '' || $pass === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Укажите e-mail и пароль.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES utf8mb4");

    list($idCol, $emailCol, $passCol) = detect_user_columns($pdo);

    $sql = "SELECT `$idCol` AS uid, `$emailCol` AS uemail, `$passCol` AS upass
            FROM users WHERE `$emailCol` = :email LIMIT 1";
    $st = $pdo->prepare($sql);
    $st->execute([':email' => $email]);
    $u = $st->fetch(PDO::FETCH_ASSOC);

    if (!$u || !verify_pass($pass, (string) $u['upass'])) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Неверный e-mail или пароль'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // успех: авторизуем
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $u['uid'];
    $_SESSION['email'] = (string) $u['uemail'];

    echo json_encode([
        'ok' => true,
        'user' => [
            'id' => (int) $u['uid'],
            'email' => (string) $u['uemail']
        ]
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    http_response_code(500);
    $payload = ['ok' => false, 'error' => 'Внутренняя ошибка сервера'];
    if (DEBUG_LOGIN)
        $payload['details'] = $e->getMessage();
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
}
