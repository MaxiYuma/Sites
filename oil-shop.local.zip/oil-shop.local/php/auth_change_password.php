<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');

require __DIR__.'/session_boot.php';
require __DIR__ . '/db.php';

/* guard */
if (empty($_SESSION['user_id'])) {
  http_response_code(401);
  echo json_encode(['error' => 'Не авторизованы']);
  exit;
}

/* body: json или x-www-form-urlencoded */
$raw  = file_get_contents('php://input');
$body = json_decode($raw, true);
if (!is_array($body)) {
  $body = $_POST;
}

$old = (string)($body['old'] ?? '');
$new = (string)($body['new'] ?? '');

if ($old === '' || $new === '') {
  http_response_code(400);
  echo json_encode(['error' => 'Заполните поля']);
  exit;
}

/* те же требования, что при регистрации */
$ok = (strlen($new) > 6)
  && preg_match('/[A-Z]/', $new)
  && preg_match('/[a-z]/', $new)
  && preg_match('/\d/',    $new)
  && preg_match('/[^A-Za-z0-9_ ]/', $new)  // спецсимвол
  && preg_match('/\s/', $new)              // пробел
  && preg_match('/\-/', $new)              // дефис
  && preg_match('/_/',  $new)              // подчёркивание
  && !preg_match('/[А-Яа-яЁё]/u', $new);   // без кириллицы

if (!$ok) {
  http_response_code(400);
  echo json_encode(['error' => 'Пароль не соответствует требованиям']);
  exit;
}

/* проверяем старый пароль */
$st = $pdo->prepare('SELECT pass_hash FROM users WHERE id=?');
$st->execute([$_SESSION['user_id']]);
$row = $st->fetch();

if (!$row || !password_verify($old, $row['pass_hash'])) {
  http_response_code(400);
  echo json_encode(['error' => 'Старый пароль неверен']);
  exit;
}

/* пишем новый */
$st = $pdo->prepare('UPDATE users SET pass_hash=? WHERE id=?');
$st->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['user_id']]);

echo json_encode(['ok' => true]);
