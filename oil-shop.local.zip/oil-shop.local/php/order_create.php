<?php
// php/order_create.php
declare(strict_types=1);
ini_set('display_errors','1'); error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/db.php';     // должен создать $pdo = new PDO(...); и session_start()

// проверяем сессию
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['ok'=>false,'error'=>'Требуется авторизация']);
    exit;
}

// читаем тело запроса (JSON или form-data)
$raw = file_get_contents('php://input');
$body = $raw ? json_decode($raw, true) : $_POST;

$name     = trim((string)($body['name'] ?? ''));
$phone    = trim((string)($body['phone'] ?? ''));
$email    = trim((string)($body['email'] ?? ''));
$city     = trim((string)($body['city'] ?? ''));
$address  = trim((string)($body['address'] ?? ''));
$delivery = trim((string)($body['delivery'] ?? 'Курьером'));
$payment  = trim((string)($body['payment'] ?? 'Картой'));
$comment  = trim((string)($body['comment'] ?? ''));

if ($name==='' || $phone==='' || $email==='') {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Заполните ФИО, телефон и e-mail']);
    exit;
}

// корзина из сессии
$cart = $_SESSION['cart'] ?? [];
if (!$cart || !is_array($cart)) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'Корзина пуста']);
    exit;
}

// считаем суммы
$total = 0.0;
foreach ($cart as $item) {
    $qty    = (int)($item['qty'] ?? 1);
    $liter  = (float)($item['liter'] ?? 1);
    $priceL = (float)($item['price_per_liter'] ?? 0);
    $total += $qty * $liter * $priceL;
}

$pdo->beginTransaction();
try {
    // orders
    $st = $pdo->prepare("
        INSERT INTO orders
          (user_id, name, phone, email, city, address, delivery, payment, comment, total_amount, status, created_at)
        VALUES
          (:uid, :name, :phone, :email, :city, :address, :delivery, :payment, :comment, :total, 'new', NOW())
    ");
    $st->execute([
        ':uid'      => $_SESSION['user_id'],
        ':name'     => $name,
        ':phone'    => $phone,
        ':email'    => $email,
        ':city'     => $city,
        ':address'  => $address,
        ':delivery' => $delivery,
        ':payment'  => $payment,
        ':comment'  => $comment,
        ':total'    => $total,
    ]);
    $orderId = (int)$pdo->lastInsertId();

    // order_items
    $sti = $pdo->prepare("
        INSERT INTO order_items
          (order_id, product_id, title, liters, qty, price_per_liter, subtotal)
        VALUES
          (:oid, :pid, :title, :liters, :qty, :priceL, :subtotal)
    ");

    foreach ($cart as $item) {
        $pid    = (int)($item['product_id'] ?? 0);
        $title  = (string)($item['title'] ?? ($item['name'] ?? 'Товар'));
        $liters = (float)($item['liter'] ?? 1);
        $qty    = (int)($item['qty'] ?? 1);
        $priceL = (float)($item['price_per_liter'] ?? 0);
        $subtotal = $qty * $liters * $priceL;

        $sti->execute([
            ':oid'    => $orderId,
            ':pid'    => $pid,
            ':title'  => $title,
            ':liters' => $liters,
            ':qty'    => $qty,
            ':priceL' => $priceL,
            ':subtotal' => $subtotal,
        ]);
    }

    $pdo->commit();

    // очищаем корзину
    $_SESSION['cart'] = [];

    echo json_encode([
        'ok' => true,
        'order_id' => $orderId,
        'redirect' => '/account.html#orders'
    ]);
} catch (Throwable $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'DB: '.$e->getMessage()]);
}
