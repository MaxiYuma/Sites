<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/session_boot.php'; // стартует сессию
require __DIR__ . '/db.php';

function ffloat($v): float { return (float)str_replace(',', '.', (string)$v); }

/**
 * Эффективная цена за 1 литр:
 *  - если есть запись в product_volumes для нужного объёма → берём price_total / литры
 *  - иначе products.price_per_liter
 *  - применяем максимальную активную скидку из promotions/product_promotions
 * @return array{unit: float, discount: float}
 */
function effectivePricePerLiter(PDO $pdo, int $productId, float $volumeLiters): array
{
    static $stVol = null, $stProd = null, $stDisc = null;

    if ($stVol === null) {
        $stVol  = $pdo->prepare(
            "SELECT price_total
               FROM product_volumes
              WHERE product_id = :pid AND volume_liters = :v
              LIMIT 1"
        );
        $stProd = $pdo->prepare(
            "SELECT name, price_per_liter
               FROM products
              WHERE id = :pid
              LIMIT 1"
        );
        $stDisc = $pdo->prepare(
            "SELECT MAX(pr.discount_percent)
               FROM product_promotions pp
               JOIN promotions pr ON pr.id = pp.promotion_id
              WHERE pp.product_id = :pid
                AND NOW() BETWEEN pr.starts_at AND pr.ends_at"
        );
    }

    $unit = 0.0; // цена за литр
    if ($volumeLiters > 0) {
        $stVol->execute([':pid' => $productId, ':v' => $volumeLiters]);
        if ($row = $stVol->fetch(PDO::FETCH_ASSOC)) {
            $priceTotal = (float)$row['price_total'];
            if ($priceTotal > 0) $unit = $priceTotal / $volumeLiters;
        }
    }

    if ($unit <= 0) {
        $stProd->execute([':pid' => $productId]);
        if ($row = $stProd->fetch(PDO::FETCH_ASSOC)) {
            $unit = (float)$row['price_per_liter'];
        }
    }

    $stDisc->execute([':pid' => $productId]);
    $disc = (float)($stDisc->fetchColumn() ?: 0);
    if ($disc > 0) $unit *= (1 - $disc / 100);

    return ['unit' => $unit, 'discount' => $disc];
}

/**
 * Генерация публичного номера заказа: YYYYMMDD-#### (счётчик внутри суток).
 * Требуется колонка orders.order_no (UNIQUE).
 */
function generateOrderNo(PDO $pdo): string
{
    $date = date('Ymd');
    // берём текущее количество заказов за сегодня и +1
    $seq = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE()")->fetchColumn() + 1;
    $candidate = $date . '-' . str_pad((string)$seq, 4, '0', STR_PAD_LEFT);

    // на случай UNIQUE-коллизии увеличим seq
    $check = $pdo->prepare("SELECT 1 FROM orders WHERE order_no = :no LIMIT 1");
    while (true) {
        $check->execute([':no' => $candidate]);
        if (!$check->fetchColumn()) break;
        $seq++;
        $candidate = $date . '-' . str_pad((string)$seq, 4, '0', STR_PAD_LEFT);
    }
    return $candidate;
}

/* ----------------------- main ----------------------- */
try {
    if (empty($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['ok'=>false,'error'=>'Нужно войти в аккаунт'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $userId = (int)$_SESSION['user_id'];

    // Получаем поля формы (FormData → $_POST)
    $in = $_POST;

    $fio      = trim($in['fio']      ?? $in['name']      ?? '');
    $phone    = trim($in['phone']    ?? $in['tel']       ?? '');
    $email    = trim($in['email']    ?? '');
    $city     = trim($in['city']     ?? $in['town']      ?? '');
    $address  = trim($in['address']  ?? $in['addr']      ?? '');
    $delivery = trim($in['delivery_text'] ?? $in['delivery'] ?? 'Курьером');
    $payment  = trim($in['payment_text']  ?? $in['payment']  ?? $in['pay'] ?? 'Картой');
    $comment  = trim($in['comment']  ?? $in['notes']     ?? '');

    $missing = [];
    if ($fio==='')     $missing[]='ФИО';
    if ($phone==='')   $missing[]='Телефон';
    if ($email==='')   $missing[]='E-mail';
    if ($address==='') $missing[]='Адрес доставки';
    if ($missing) {
        http_response_code(400);
        echo json_encode(['ok'=>false,'error'=>'Заполните обязательные поля: '.implode(', ', $missing)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Корзина из сессии
    $cart = $_SESSION['cart'] ?? [];
    if (isset($cart['items']) && is_array($cart['items'])) $cart = $cart['items'];

    // Нормализация
    $rows = [];
    foreach ((array)$cart as $it) {
        if (!is_array($it)) continue;
        $pid   = (int)($it['product_id'] ?? $it['id'] ?? 0);
        $name  = (string)($it['name'] ?? $it['product_name'] ?? '');
        $qty   = (int)($it['qty'] ?? $it['quantity'] ?? 1);
        $volS  = (string)($it['volume_l'] ?? $it['volume'] ?? $it['liters'] ?? '1.00');
        $vol   = ffloat($volS);
        if ($pid<=0 && $name==='') continue;
        if ($qty < 1) $qty = 1;
        $rows[] = ['product_id'=>$pid,'name'=>$name,'qty'=>$qty,'liters_str'=>$volS,'liters'=>$vol>0?$vol:1.0];
    }
    if (!$rows) {
        http_response_code(400);
        echo json_encode(['ok'=>false,'error'=>'Корзина пуста'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES utf8mb4");

    // Считаем позиции и итог с учётом акций
    $items = [];
    $orderTotal = 0.0;

    foreach ($rows as $r) {
        $pid = $r['product_id'];
        $qty = $r['qty'];
        $litersNum = (float)$r['liters'];
        $litersStr = $r['liters_str'];

        $calc = effectivePricePerLiter($pdo, $pid, $litersNum ?: 1);
        $ppl  = (float)$calc['unit'];                 // цена за 1 л (со скидкой)
        $line = $ppl * $litersNum * $qty;

        $orderTotal += $line;

        $items[] = [
            'product_id'      => $pid,
            'product_name'    => $r['name'],
            'liters'          => $litersStr,
            'qty'             => $qty,
            'price_per_liter' => round($ppl, 2),
            'line_total'      => round($line, 2),
        ];
    }

    // Пишем заказ
    $pdo->beginTransaction();

    // публичный номер
    $orderNo = generateOrderNo($pdo);

    // ВАЖНО: в таблице orders должна быть колонка order_no VARCHAR UNIQUE
    $sqlOrder = "INSERT INTO orders
        (user_id, order_no, fio, phone, email, city, address, delivery, payment, comment, total, status, created_at)
        VALUES (:uid, :order_no, :fio, :phone, :email, :city, :addr, :delivery, :payment, :comment, :total, 'новый', NOW())";
    $pdo->prepare($sqlOrder)->execute([
        ':uid'=>$userId, ':order_no'=>$orderNo,
        ':fio'=>$fio, ':phone'=>$phone, ':email'=>$email,
        ':city'=>$city, ':addr'=>$address,
        ':delivery'=>$delivery, ':payment'=>$payment, ':comment'=>$comment,
        ':total'=>$orderTotal
    ]);
    $orderId = (int)$pdo->lastInsertId();

    // Позиции
    $stItem = $pdo->prepare("INSERT INTO order_items
        (order_id, product_id, product_name, liters, qty, price_per_liter, line_total)
        VALUES (:oid, :pid, :name, :liters, :qty, :ppl, :sum)");
    foreach ($items as $it) {
        $stItem->execute([
            ':oid'=>$orderId,
            ':pid'=>$it['product_id'],
            ':name'=>$it['product_name'],
            ':liters'=>$it['liters'],
            ':qty'=>$it['qty'],
            ':ppl'=>$it['price_per_liter'],
            ':sum'=>$it['line_total'],
        ]);
    }

    // чистим корзину
    unset($_SESSION['cart']);

    $pdo->commit();

    echo json_encode(['ok'=>true,'id'=>$orderId,'order_no'=>$orderNo], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode([
        'ok'=>false,
        'error'=>'Внутренняя ошибка сервера',
        'details'=>$e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
