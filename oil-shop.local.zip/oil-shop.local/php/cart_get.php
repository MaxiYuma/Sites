<?php
// php/cart_get.php — версия с учётом скидок
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/session_boot.php'; // старт сессии
require __DIR__ . '/db.php';           // $pdo (PDO)

function fnum(float $v): string { return number_format($v, 2, ',', ' '); }
function money(float $v): string { return fnum($v) . ' ₽'; }

/**
 * Возвращает ЭФФЕКТИВНУЮ цену за 1 литр с учётом:
 *  - product_volumes.price_total (если есть запись для объёма),
 *  - products.price_per_liter (если нет записи для объёма),
 *  - максимальной активной скидки из promotions/product_promotions (в процентах).
 *
 * @return array{unit: float, discount: float}
 */
function effectivePricePerLiter(PDO $pdo, int $productId, float $volumeLiters): array
{
    static $stVol = null, $stProd = null, $stDisc = null;

    if ($stVol === null) {
        $stVol  = $pdo->prepare(
            "SELECT price_total 
             FROM product_volumes 
             WHERE product_id = :pid AND volume_liters = :v 
             LIMIT 1"
        );
        $stProd = $pdo->prepare(
            "SELECT price_per_liter 
             FROM products 
             WHERE id = :pid 
             LIMIT 1"
        );
        // берём максимальную скидку по всем активным акциям
        $stDisc = $pdo->prepare(
            "SELECT MAX(pr.discount_percent) 
               FROM product_promotions pp
               JOIN promotions pr ON pr.id = pp.promotion_id
              WHERE pp.product_id = :pid
                AND NOW() BETWEEN pr.starts_at AND pr.ends_at"
        );
    }

    // 1) пробуем цену за канистру
    $unit = 0.0;
    if ($volumeLiters > 0) {
        $stVol->execute([':pid' => $productId, ':v' => $volumeLiters]);
        if ($row = $stVol->fetch(PDO::FETCH_NUM)) {
            $priceTotal = (float)$row[0];
            if ($priceTotal > 0) {
                $unit = $priceTotal / $volumeLiters; // цена за литр
            }
        }
    }

    // 2) иначе берём price_per_liter из products
    if ($unit <= 0) {
        $stProd->execute([':pid' => $productId]);
        if ($row = $stProd->fetch(PDO::FETCH_NUM)) {
            $unit = (float)$row[0];
        }
    }

    // 3) применяем скидку (если есть активная)
    $stDisc->execute([':pid' => $productId]);
    $disc = (float)($stDisc->fetchColumn() ?: 0);
    if ($disc > 0) {
        $unit *= (1 - $disc / 100);
    }

    return ['unit' => $unit, 'discount' => $disc];
}

/**
 * Унифицируем структуру элемента корзины из сессии.
 * Ожидаем, что в сессии могут быть разные ключи:
 *   product_id/id, name/product_name, volume_l/liters/volume, qty/quantity
 */
function normalizeCart(array $raw): array
{
    // некоторые проекты кладут в $_SESSION['cart']['items']
    if (isset($raw['items']) && is_array($raw['items'])) {
        $raw = $raw['items'];
    }
    $norm = [];
    foreach ($raw as $key => $it) {
        if (!is_array($it)) continue;
        $pid  = (int)($it['product_id'] ?? $it['id'] ?? 0);
        $name = (string)($it['name'] ?? $it['product_name'] ?? '');
        $vol  = (float)($it['volume_l'] ?? $it['liters'] ?? $it['volume'] ?? 1);
        $qty  = (int)($it['qty'] ?? $it['quantity'] ?? 1);
        if ($pid <= 0 && $name === '') continue;

        $norm[] = [
            // ключ позиции для удаления (если у тебя уже есть свой key — подставь его)
            'key'       => is_string($key) ? $key : (string)$key,
            'product_id'=> $pid,
            'name'      => $name,
            'volume_l'  => $vol > 0 ? $vol : 1,
            'qty'       => $qty > 0 ? $qty : 1,
        ];
    }
    return $norm;
}

try {
    $itemsRaw = $_SESSION['cart'] ?? [];
    $items    = normalizeCart($itemsRaw);

    // Если корзина пуста — отдадим пустой ответ
    if (!$items) {
        echo json_encode([
            'items' => [],
            'count' => 0,
            'total' => 0,
            'total_fmt' => money(0.0)
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES utf8mb4");

    $total = 0.0;
    $out   = [];

    foreach ($items as $it) {
        $pid   = $it['product_id'];
        $vol   = (float)$it['volume_l'];
        $qty   = (int)$it['qty'];

        // цена за литр с учётом акций
        $calc  = effectivePricePerLiter($pdo, $pid, $vol > 0 ? $vol : 1);
        $ppl   = (float)$calc['unit'];                 // price per liter (final)
        $unit  = $ppl * ($vol > 0 ? $vol : 1);         // цена ЕДИНИЦЫ (канистры)
        $sum   = $unit * $qty;

        $total += $sum;

        $out[] = [
            'key'      => $it['key'],
            'product_id' => $pid,
            'name'     => $it['name'],
            'volume_l' => $vol,
            'qty'      => $qty,
            'unit'     => round($unit, 2),
            'sum'      => round($sum, 2),
            'unit_fmt' => money($unit),
            'sum_fmt'  => money($sum),
        ];
    }

    echo json_encode([
        'items'     => $out,
        'count'     => array_sum(array_column($items, 'qty')),
        'total'     => round($total, 2),
        'total_fmt' => money($total),
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Не удалось получить корзину',
        'details' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
