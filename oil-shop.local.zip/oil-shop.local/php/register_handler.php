<?php
require __DIR__.'/db.php';
require __DIR__.'/password_policy.php';

$email=trim($_POST['email']??'');
$name =trim($_POST['full_name']??'');
$pw   =$_POST['password']??'';

[$ok,$errs]=validate_password($pw);
if(!$ok){ header('Location: ../register.html'); exit; }
if(!filter_var($email, FILTER_VALIDATE_EMAIL)){ header('Location: ../register.html'); exit; }

try{
  $pdo->prepare('INSERT INTO customers(email,password_hash,full_name) VALUES(?,?,?)')
      ->execute([$email, password_hash($pw, PASSWORD_DEFAULT), $name]);
  header('Location: ../index.html');
}catch(PDOException $e){
  header('Location: ../register.html');
}
