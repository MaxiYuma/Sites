<?php
return [
  'dsn'  => 'mysql:host=127.0.1.29;port=3306;dbname=oil_shop;charset=utf8mb4',
  'user' => 'root',   // твой логин
  'pass' => '',       // твой пароль
];
