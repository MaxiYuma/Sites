<?php
ini_set('display_errors',1); error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
require __DIR__.'/db.php';

$items=[];
try{
  $st=$pdo->query("SELECT id,title,description,discount_percent,starts_at,ends_at
                   FROM promotions
                   WHERE NOW() BETWEEN starts_at AND ends_at
                   ORDER BY starts_at DESC");
  while($r=$st->fetch()){
    $items[]=[
      'id'=>(int)$r['id'],
      'title'=>$r['title'],
      'description'=>$r['description'],
      'discount_percent'=>(float)$r['discount_percent'],
      'period'=>date('d.m.Y',strtotime($r['starts_at'])).' — '.date('d.m.Y',strtotime($r['ends_at'])),
    ];
  }
}catch(Throwable $e){ /* если таблиц нет — вернём пусто */ }
echo json_encode(['items'=>$items], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
