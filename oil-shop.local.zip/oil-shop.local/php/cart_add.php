<?php
require __DIR__.'/session_boot.php';
require __DIR__.'/db.php';
header('Content-Type: application/json; charset=utf-8');

$body = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$productId = (int)($body['product_id'] ?? 0);
$volume    = (float)($body['volume_l']   ?? 1);
$qty       = max(1, (int)($body['qty']   ?? 1));

if ($productId<=0 || $volume<=0) { http_response_code(400); echo json_encode(['error'=>'bad params']); exit; }

$st=$pdo->prepare("SELECT id,name,price_per_liter FROM products WHERE id=?");
$st->execute([$productId]);
$p=$st->fetch();
if(!$p){ http_response_code(404); echo json_encode(['error'=>'product not found']); exit; }

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) $_SESSION['cart'] = [];
$key = $productId.'@'.$volume;

if (!isset($_SESSION['cart'][$key])) {
  $_SESSION['cart'][$key] = [
    'product_id'=>(int)$p['id'],
    'name'=>$p['name'],
    'volume_l'=>$volume,
    'qty'=>0,
    'price_per_l'=>(float)$p['price_per_liter'],
  ];
}
$_SESSION['cart'][$key]['qty'] += $qty;

require __DIR__.'/cart_get.php'; // вернёт сводку
