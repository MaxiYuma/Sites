<?php
$https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
session_set_cookie_params([
  'lifetime'=>86400*7, 'path'=>'/', 'domain'=>'',
  'secure'=>$https, 'httponly'=>true, 'samesite'=>'Lax',
]);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
