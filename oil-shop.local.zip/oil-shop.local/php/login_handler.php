<?php
require __DIR__.'/db.php';
session_start();
$email=trim($_POST['email']??'');
$pw=$_POST['password']??'';
$stmt=$pdo->prepare('SELECT id,password_hash FROM customers WHERE email=?');
$stmt->execute([$email]); $u=$stmt->fetch();
if($u && password_verify($pw,$u['password_hash'])){
  $_SESSION['customer_id']=$u['id'];
  header('Location: ../index.html');
}else{
  header('Location: ../login.html');
}
