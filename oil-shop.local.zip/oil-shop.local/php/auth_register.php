<?php
// ВКЛЮЧАЕМ ОШИБКИ В ОТВЕТЕ (на время отладки можно оставить)
ini_set('display_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/db.php';

/* ---------- ЧТЕНИЕ ТЕЛА ЗАПРОСА (json или обычная форма) ---------- */
$raw = file_get_contents('php://input');
$body = json_decode($raw, true);
if (!is_array($body)) {
    // fallback на обычные формы
    $body = $_POST;
}

$email = isset($body['email']) ? trim((string)$body['email']) : '';
$pass  = isset($body['password']) ? (string)$body['password'] : '';

/* ---------- ПРОВЕРКИ ---------- */
$errors = [];

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Некорректный e-mail.';
}

if ($pass === '') {
    $errors[] = 'Пароль пустой.';
} else {
    if (strlen($pass) <= 6)                               $errors[] = 'Длина пароля должна быть больше 6.';
    if (!preg_match('/[A-Z]/', $pass))                    $errors[] = 'Нужна хотя бы одна заглавная латинская буква (A–Z).';
    if (!preg_match('/[a-z]/', $pass))                    $errors[] = 'Нужна хотя бы одна строчная латинская буква (a–z).';
    if (!preg_match('/\d/', $pass))                       $errors[] = 'Нужна хотя бы одна цифра.';
    if (!preg_match('/[^A-Za-z0-9_ ]/', $pass))           $errors[] = 'Нужен хотя бы один спецсимвол (.,!@# и т. п.).';
    if (!preg_match('/\s/', $pass))                       $errors[] = 'Обязательно наличие пробела.';
    if (!preg_match('/\-/', $pass))                       $errors[] = 'Обязательно наличие дефиса (-).';
    if (!preg_match('/_/', $pass))                        $errors[] = 'Обязательно наличие подчёркивания (_).';
    if (preg_match('/[А-Яа-яЁё]/u', $pass))               $errors[] = 'Русские буквы запрещены.';
}

/* Если валидатор нашёл ошибки — вернём 400 с перечислением */
if ($errors) {
    http_response_code(400);
    echo json_encode(['error' => implode(' ', $errors)]);
    exit;
}

/* ---------- ТАБЛИЦА USERS (если нет) ---------- */
$pdo->exec("CREATE TABLE IF NOT EXISTS users(
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) UNIQUE NOT NULL,
  pass_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

/* ---------- ЗАПИСЫВАЕМ ПОЛЬЗОВАТЕЛЯ ---------- */
try {
    $st = $pdo->prepare("INSERT INTO users(email, pass_hash) VALUES(?, ?)");
    $st->execute([$email, password_hash($pass, PASSWORD_DEFAULT)]);
    echo json_encode(['ok' => true]);
} catch (Throwable $e) {
    // 23000 — дубликат уникального ключа (email уже есть)
    http_response_code(400);
    if ((int)$e->getCode() === 23000) {
        echo json_encode(['error' => 'Такой e-mail уже зарегистрирован.']);
    } else {
        echo json_encode(['error' => 'Ошибка: ' . $e->getMessage()]);
    }
}
