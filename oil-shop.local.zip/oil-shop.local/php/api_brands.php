<?php
require __DIR__.'/db.php';
header('Content-Type: application/json; charset=utf-8');
$rows = $pdo->query("SELECT id,name FROM brands ORDER BY name")->fetchAll();
echo json_encode(['items'=>$rows], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
