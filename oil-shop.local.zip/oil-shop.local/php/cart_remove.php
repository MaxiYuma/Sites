<?php
require __DIR__.'/session_boot.php';
header('Content-Type: application/json; charset=utf-8');

$body = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$key  = (string)($body['key'] ?? '');
if ($key==='' || !isset($_SESSION['cart'][$key])) { http_response_code(400); echo json_encode(['error'=>'bad key']); exit; }

unset($_SESSION['cart'][$key]);
require __DIR__.'/cart_get.php';
