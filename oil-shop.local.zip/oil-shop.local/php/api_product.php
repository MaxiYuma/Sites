<?php
ini_set('display_errors',1); error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');

require __DIR__.'/db.php';
require __DIR__.'/helpers.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id<=0){ http_response_code(400); echo json_encode(['error'=>'id required']); exit; }

$st = $pdo->prepare("SELECT p.*, b.name AS brand, ot.name AS type_name
                     FROM products p
                     JOIN brands b    ON b.id=p.brand_id
                     JOIN oil_types ot ON ot.id=p.type_id
                     WHERE p.id=? LIMIT 1");
$st->execute([$id]);
$row = $st->fetch();
if(!$row){ http_response_code(404); echo json_encode(['error'=>'not found']); exit; }

$disc  = active_promo_discount($pdo,(int)$row['id']); // % скидки
$final_per_liter = price_with_discount((float)$row['price_per_liter'],$disc);

// Фасовки / варианты
$vs = $pdo->prepare("SELECT id, volume_liters, price_total
                     FROM product_volumes WHERE product_id=? ORDER BY volume_liters");
$vs->execute([$id]);
$variants = [];
while($v = $vs->fetch()){
  $total = (float)$v['price_total'];
  $final_total = $disc>0 ? round($total * (1 - $disc/100), 2) : $total;
  $variants[] = [
    'id' => (int)$v['id'],
    'volume' => (float)$v['volume_liters'],
    'total'  => $total,
    'total_fmt' => money($total),
    'final_total' => $final_total,
    'final_total_fmt' => money($final_total),
    'per_liter' => round($final_total / (float)$v['volume_liters'], 2),
    'per_liter_fmt' => money(round($final_total / (float)$v['volume_liters'], 2)),
  ];
}

// Базовый ответ
echo json_encode(['item'=>[
  'id'=>(int)$row['id'],
  'name'=>$row['name'],
  'brand'=>$row['brand'],
  'type'=>$row['type_name'],
  'viscosity'=>$row['viscosity'],
  'description'=>$row['description'],
  'image_url'=>$row['image_url'],
  'price_per_liter'=>(float)$row['price_per_liter'],
  'price_per_liter_fmt'=>money($row['price_per_liter']),
  'discount'=>$disc,
  'final_per_liter'=>$final_per_liter,
  'final_per_liter_fmt'=>money($final_per_liter),
  'variants'=>$variants
]], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
