<?php
function money($n){ return number_format($n,2,',',' ').' ₽'; }

function active_promo_discount(PDO $pdo, int $productId): float {
  try { $pdo->query("SELECT 1 FROM promotions LIMIT 1"); $pdo->query("SELECT 1 FROM product_promotions LIMIT 1"); }
  catch(Throwable $e){ return 0.0; }

  try{
    $st=$pdo->prepare("SELECT p.discount_percent
                       FROM promotions p JOIN product_promotions pp ON p.id=pp.promotion_id
                       WHERE pp.product_id=? AND NOW() BETWEEN p.starts_at AND p.ends_at
                       ORDER BY p.discount_percent DESC LIMIT 1");
    $st->execute([$productId]); $row=$st->fetch();
    return $row ? (float)$row['discount_percent'] : 0.0;
  }catch(Throwable $e){ return 0.0; }
}
function price_with_discount($price,$discount){ return $discount>0? round($price*(1-$discount/100),2) : $price; }
