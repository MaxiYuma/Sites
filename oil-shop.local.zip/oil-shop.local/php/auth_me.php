<?php
ini_set('display_errors',1); error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');

require __DIR__.'/session_boot.php';
require __DIR__.'/db.php';

if (empty($_SESSION['user_id'])) { echo json_encode(['ok'=>false]); exit; }

$st=$pdo->prepare("SELECT id,email,created_at FROM users WHERE id=? LIMIT 1");
$st->execute([$_SESSION['user_id']]);
$u=$st->fetch();
if(!$u){ session_destroy(); echo json_encode(['ok'=>false]); exit; }

echo json_encode(['ok'=>true,'user'=>['id'=>(int)$u['id'],'email'=>$u['email'],'created_at'=>$u['created_at']]]);
