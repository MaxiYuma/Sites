<?php
// php/db.php
$cfgOrBool = @include __DIR__.'/config.php';
if ($cfgOrBool === false) {
  http_response_code(500);
  die('config.php не найден в /php');
}

if (is_array($cfgOrBool)) {
  // Вариант А: config.php возвращает массив
  $dsn  = $cfgOrBool['dsn']  ?? '';
  $user = $cfgOrBool['user'] ?? '';
  $pass = $cfgOrBool['pass'] ?? '';
} else {
  // Вариант Б: config.php объявляет переменные
  require __DIR__.'/config.php'; // на случай, если include вернул true
  $dsn  = isset($DB_HOST,$DB_NAME) ? "mysql:host=$DB_HOST;port=3306;dbname=$DB_NAME;charset=utf8mb4" : '';
  $user = $DB_USER ?? '';
  $pass = $DB_PASS ?? '';
}

if (!$dsn) { http_response_code(500); die('В config.php нет DSN/параметров БД'); }

try {
  $pdo = new PDO($dsn, $user, $pass, [
    PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
  ]);
} catch (PDOException $e) {
  http_response_code(500);
  die('DB connection failed: '.htmlspecialchars($e->getMessage()));
}
