<?php
require __DIR__.'/db.php';
require __DIR__.'/helpers.php';
header('Content-Type: application/json; charset=utf-8');

try{
  $where=[];$params=[];
  if(!empty($_GET['brand'])){$where[]='p.brand_id=?';$params[]=$_GET['brand'];}
  if(!empty($_GET['type'])) {$where[]='p.type_id=?';$params[]=$_GET['type'];}
  if(!empty($_GET['ids'])){
    $ids = array_filter(array_map('intval', explode(',', $_GET['ids'])));
    if($ids){ $where[] = 'p.id IN ('.implode(',', $ids).')'; }
  }
  $limit = isset($_GET['limit']) ? max(1, min(48, intval($_GET['limit']))) : 0;

  $sql='SELECT p.*, b.name brand FROM products p JOIN brands b ON b.id=p.brand_id'
      .(count($where)?' WHERE '.implode(' AND ',$where):'')
      .' ORDER BY p.created_at DESC'.($limit?" LIMIT $limit":'');
  $stmt=$pdo->prepare($sql); $stmt->execute($params);

  $items=[];
  foreach($stmt as $r){
    $disc=active_promo_discount($pdo,(int)$r['id']);
    $final=price_with_discount($r['price_per_liter'],$disc);
    $items[]=[
      'id'=>(int)$r['id'],
      'name'=>$r['name'],
      'brand'=>$r['brand'],
      'viscosity'=>$r['viscosity'],
      'image_url'=>$r['image_url'],
      'description'=>$r['description'],
      'price'=>(float)$r['price_per_liter'],
      'price_fmt'=>money($r['price_per_liter']),
      'discount'=>$disc,
      'final'=>$final,
      'final_fmt'=>money($final)
    ];
  }
  echo json_encode(['items'=>$items], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
}catch(Throwable $e){
  http_response_code(500);
  echo json_encode(['error'=>$e->getMessage()]);
}

ini_set('display_errors',1); error_reporting(E_ALL);

