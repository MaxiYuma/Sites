<?php
require __DIR__.'/db.php';
session_start();
header('Content-Type: application/json; charset=utf-8');

if(empty($_SESSION['customer_id'])){
  http_response_code(401);
  echo json_encode(['error'=>'login']); exit;
}
$payload=json_decode(file_get_contents('php://input'),true);
$items=$payload['items']??[];
if(!$items){ http_response_code(400); echo json_encode(['error'=>'empty']); exit; }

$pdo->beginTransaction();
$pdo->prepare('INSERT INTO orders(customer_id,total_amount) VALUES(?,0)')->execute([$_SESSION['customer_id']]);
$orderId=$pdo->lastInsertId(); $total=0;

foreach($items as $it){
  $id=(int)$it['id']; $liters=(float)$it['liters']; $qty=(int)$it['qty'];
  $p=$pdo->prepare('SELECT price_per_liter FROM products WHERE id=?'); $p->execute([$id]); $row=$p->fetch();
  if(!$row) continue;
  $price=(float)$row['price_per_liter'];
  $line=$price*$liters*$qty; $total+=$line;
  $pdo->prepare('INSERT INTO order_items(order_id,product_id,quantity,price_per_liter,liters)
                 VALUES(?,?,?,?,?)')->execute([$orderId,$id,$qty,$price,$liters]);
}
$pdo->prepare('UPDATE orders SET total_amount=? WHERE id=?')->execute([$total,$orderId]);
$pdo->commit();
echo json_encode(['ok'=>true,'order_id'=>$orderId]);
