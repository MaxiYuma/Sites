<?php
function validate_password(string $pw): array {
  $err=[];
  if(mb_strlen($pw,'UTF-8')<7) $err[]='≥ 7 символов';
  if(!preg_match('/[A-Z]/',$pw)) $err[]='Нет заглавной (A–Z)';
  if(!preg_match('/[a-z]/',$pw)) $err[]='Нет строчной (a–z)';
  if(!preg_match('/[0-9]/',$pw)) $err[]='Нет цифры';
  if(!preg_match('/[!"#$%&\'()*+,.\/:;<=>?@\[\]^`{|}~\\\\]/',$pw)) $err[]='Нет спецсимвола';
  if(!str_contains($pw,' ')) $err[]='Нет пробела';
  if(!str_contains($pw,'-')) $err[]='Нет дефиса -';
  if(!str_contains($pw,'_')) $err[]='Нет подчеркивания _';
  if(preg_match('/[А-Яа-яЁё]/u',$pw)) $err[]='Русские буквы запрещены';
  return [count($err)===0, $err];
}
