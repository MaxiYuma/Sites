<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/session_boot.php';
require __DIR__ . '/db.php';

try {
    if (empty($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Нужно войти']);
        exit;
    }
    $userId = (int)$_SESSION['user_id'];
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES utf8mb4");

    $st = $pdo->prepare("
        SELECT id, total, status, created_at
        FROM orders
        WHERE user_id = :uid
        ORDER BY id DESC
        LIMIT 200
    ");
    $st->execute([':uid' => $userId]);
    $orders = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $stFirst = $pdo->prepare("
        SELECT product_name, liters
        FROM order_items
        WHERE order_id = :oid
        ORDER BY id ASC
        LIMIT 1
    ");

    foreach ($orders as &$o) {
        $o['id']        = (int)$o['id'];
        $o['total']     = (float)$o['total'];
        $o['total_fmt'] = number_format($o['total'], 2, ',', ' ') . ' ₽';

        $title = null;
        $stFirst->execute([':oid' => $o['id']]);
        if ($fi = $stFirst->fetch(PDO::FETCH_ASSOC)) {
            $pname = trim((string)$fi['product_name']);
            $liters= trim((string)$fi['liters']);
            $title = $pname . ($liters !== '' ? ' · ' . $liters : '');
        }

        // ИМЕННО ЗДЕСЬ подменяем статус для вывода:
        if ($title) $o['status'] = $title;
    }
    unset($o);

    echo json_encode(['items' => $orders], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Не удалось получить список заказов', 'details' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
